# 调用与交付示例

## 简短需求 先问再写

用户：帮我写一个中世纪女骑士的提示词。
回复：已知是中世纪女性骑士。请补充：年龄感偏20多岁、30多岁还是40岁以上？画风偏写实、电影感3D还是2D？盔甲偏实战朴素还是华丽仪式感？不确定的项可以让我来定。
此时等待回答，不立即按自己想法交付完整提示词。

## 已有文本 直接提取

用户：角色林岚，38岁女骑士，深棕编发，左眉旧疤，钢甲与酒红披风，左腰长剑，电影感3D。生成中文四视图提示词。

中文正向提示词：
一张横向角色设定图，同一位38岁女性骑士林岚的四种视图。左侧依次排列正面、角色自身左侧90度侧面、背面三个全身图，放松A姿势，同一尺度，脚底同一水平线，头顶与鞋底完整入画；右侧为放大的胸部以上3/4角度特写。各视图保持清晰间距，不互相遮挡。
深棕色编发，左眉有一道愈合旧疤，表情沉静。穿结构实用的钢制盔甲与酒红色披风，角色自身左腰佩一把带鞘长剑。所有视图保持同一脸部结构、年龄感、发型、服装、伤痕侧别和佩剑位置；背面不回头，侧面不是3/4角度。
电影感3D，可信金属反光和布料垂坠，避免塑料质感。浅灰背景，均匀柔光，稳定白平衡，弱透视。无文字、无标签、无水印，不出现无关人物，不裁切头脚。

中文锁定卡：林岚、38岁女性、深棕编发、左眉旧疤、钢制盔甲、酒红披风、左腰带鞘长剑、电影感3D。
设置建议：横向16:9；未指定工具，不添加平台专属参数。

## 用户要双语 附同义英文

将上面的完整中文放在前面，再提供以下独立英文版，不能只给英文：

One landscape character reference sheet showing four views of the same 38-year-old female knight, Lin Lan. On the left, arrange front, exact anatomical left-side profile and back full-body views, in a relaxed A-pose, at equal scale with feet aligned on one baseline and complete heads and shoes visible. On the right, place an enlarged three-quarter chest-up portrait. Keep clear spacing without overlap.
Dark chestnut braided hair, a healed scar through her anatomical left eyebrow, and a composed expression. Practical steel armor, a burgundy cloak, and one sheathed longsword at her anatomical left hip. Keep facial structure, apparent age, hairstyle, outfit, scar side and sword placement identical across views. The back view faces away without looking back; the side view is exactly 90 degrees, not three-quarter.
Cinematic 3D with believable metal reflections and cloth drape, avoiding plastic-looking materials. Pale gray background, even soft light, stable white balance and weak perspective. No text, labels, watermark, unrelated people or cropped heads and feet.

两种语言任选一种投喂，按语言分别计数。以上为输出格式示例，不表示已生成图片。

## 局部修改

用户：沿用C001，只把酒红披风改成墨绿，给中文。
处理：只更新披风色彩及锁定卡对应项，不重新问年龄、性别、风格，不添加新五官或道具。

## 用户授权代选

用户：设计一个无性别木制机器人，定格风，其余你定，不用提问。
处理：直接给中文设计和提示词，不问男女；木纹、关节、漆面等补充标为设计提案，不套人类毛孔、血管或虹膜模板。
